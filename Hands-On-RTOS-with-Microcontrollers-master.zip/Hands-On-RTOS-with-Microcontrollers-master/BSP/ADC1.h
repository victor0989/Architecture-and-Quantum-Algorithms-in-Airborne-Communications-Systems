#ifndef ADC1_H_
#define ADC1_H_

#include <stm32f7xx_hal.h>

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
void ADC1_Init(void);

#endif /* ADC1_H_ */
